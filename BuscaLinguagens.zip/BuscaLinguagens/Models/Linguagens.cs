﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscaLinguagens.Models
{
	public class Linguagens
	{
		public List<Linguagem> linguagens = new List<Linguagem>();

		public void AdicionarLinguagem(Linguagem linguagem)
		{
			Console.Write("Insira o nome da linguagem: ");
			string nome = Console.ReadLine();
			Console.Write("Insira o ano de criação: ");
			int ano = int.Parse(Console.ReadLine());
			Console.Write("Insira o nome do Desenvolvedor Chefe: ");
			string desenvolvedorChefe = Console.ReadLine();
			Console.Write("Insira os predecessores: ");
			string predecessores = Console.ReadLine();

			linguagem = new Linguagem(ano, nome, desenvolvedorChefe, predecessores);
			linguagens.Add(linguagem);
			Console.WriteLine("Linguagem adicionada!");
			Console.WriteLine();
		}

		public void RemoverLinguagem()
		{
			if (linguagens.Count == 0)
			{
				Console.WriteLine("Nenhuma linguagem disponível.");
				Console.WriteLine();
				return;
			}

			Console.Write("Digite o nome da linguagem que deseja remover: ");
			string nome = Console.ReadLine();

			Linguagem linguagem = linguagens.FirstOrDefault(l => l.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
			if (linguagem != null)
			{
				linguagens.Remove(linguagem);
				Console.WriteLine("Linguagem removida!");
				Console.WriteLine();
			}
			else
			{
				Console.WriteLine("Linguagem não encontrada.");
				Console.WriteLine();
			}
		}

		public void BuscarLinguagemPorNome()
		{
			Console.Write("Digite o nome da linguagem que deseja buscar: ");
			string nome = Console.ReadLine();

			Linguagem linguagem = linguagens.FirstOrDefault(l => l.Nome.StartsWith(nome, StringComparison.OrdinalIgnoreCase));
			if (linguagem != null)
			{
				Console.WriteLine("Linguagem encontrada:");
				linguagem.Imprimir();
				Console.WriteLine();
			}
			else
			{
				Console.WriteLine("Linguagem não encontrada.");
				Console.WriteLine();
			}
		}
		public void BuscarPorAno()
		{
			Console.Write("Digite o ano da linguagem: ");
			int ano;
			if (int.TryParse(Console.ReadLine(), out ano))
			{
				Linguagem linguagem = linguagens.FirstOrDefault(l => l.Ano.Equals(ano));
				if (linguagem != null)
				{
					Console.WriteLine("Linguagem encontrada:");
					linguagem.Imprimir();
					Console.WriteLine();
				}
				else
				{
					Console.WriteLine("Linguagem não encontrada.");
					Console.WriteLine();
				}
			}
			else
			{
				Console.WriteLine("Ano inválido.");
				Console.WriteLine();
			}
		}

		public void BuscarPorDesenvolvedorChefe()
		{
			Console.Write("Digite o nome do Desenvolvedor Chefe: ");
			string nomeDesenvolvedorChefe = Console.ReadLine();

			Linguagem linguagem = linguagens.FirstOrDefault(l => l.DesenvolvedorChefe.Contains(nomeDesenvolvedorChefe));
			if (linguagem != null)
			{
				Console.WriteLine("Linguagem encontrada:");
				linguagem.Imprimir();
				Console.WriteLine();
			}
			else
			{
				Console.WriteLine("Linguagem não encontrada.");
				Console.WriteLine();
			}
		}

		public void BuscarPorPredescessor()
		{
			Console.Write("Digite o nome do predecessor: ");
			string nomePredescessor = Console.ReadLine();

			Linguagem linguagem = linguagens.FirstOrDefault(l => l.Predecessores.Contains(nomePredescessor));
			if (linguagem != null)
			{
				Console.WriteLine("Linguagem encontrada:");
				linguagem.Imprimir();
				Console.WriteLine();
			}
			else
			{
				Console.WriteLine("Linguagem não encontrada.");
				Console.WriteLine();
			}
		}

	}
}
