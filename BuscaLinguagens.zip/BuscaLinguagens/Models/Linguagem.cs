﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscaLinguagens.Models
{
	public class Linguagem
	{
		public int Ano;
		public string Nome;
		public string DesenvolvedorChefe;
		public string Predecessores;

		public Linguagem(int ano, string nome, string desenvolvedorChefe, string predecessores)
		{
			Ano = ano;
			Nome = nome;
			DesenvolvedorChefe = desenvolvedorChefe;
			Predecessores = predecessores;
		}

		public void Imprimir()
		{
			Console.WriteLine("------------------------------------------");
			Console.WriteLine("Nome: " + Nome);
			Console.WriteLine("Ano de criação: " + Ano);
			Console.WriteLine("Desenvolvedor Chefe: " + DesenvolvedorChefe);
			Console.WriteLine("Predecessores: " + Predecessores);
			Console.WriteLine("------------------------------------------");
		}
	}
}
