﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BuscaLinguagens.Models;

namespace BuscaLinguagens
{
	public class Program
	{
		static void Main(string[] args)
		{
			Linguagens linguagens = new Linguagens();
			bool rodando = true;

			while (rodando)
			{
				Console.WriteLine("-- MENU --");
				Console.WriteLine("1. Adicionar Linguagem");
				Console.WriteLine("2. Remover Linguagem");
				Console.WriteLine("3. Buscar por Nome");
				Console.WriteLine("4. Buscar por Ano");
				Console.WriteLine("5. Buscar por Desenvolvedor Chefe");
				Console.WriteLine("6. Buscar por Predecessor");
				Console.WriteLine("8. Sair");
				Console.WriteLine("-------------------------------------------");
				Console.Write("Escolha uma das opções: ");
				string choice = Console.ReadLine();

				switch (choice)
				{
					case "1":
						linguagens.AdicionarLinguagem(null);
						break;
					case "2":
						linguagens.RemoverLinguagem();
						break;
					case "3":
						linguagens.BuscarLinguagemPorNome();
						break;
					case "4":
						linguagens.BuscarPorAno();
						break;
					case "5":
						linguagens.BuscarPorDesenvolvedorChefe();
						break;
					case "6":
						linguagens.BuscarPorPredescessor();
						break;
					case "8":
						rodando = false;
						break;
					default:
						Console.WriteLine("Opção inválida");
						break;
				}
			}
		}
	}
}