﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArvoreGenealogica.Models
{
	public class Pessoa
	{
		public string nome;
		public Pessoa pai;
		public Pessoa conjuge;
		public List<Pessoa> filhos;
		public Pessoa(string nome)
		{
			this.nome = nome;
			this.filhos = new List<Pessoa>();
		}
		public Pessoa(string nome, Pessoa pai)
		{
			this.nome = nome;
			this.pai = pai;
			this.filhos = new List<Pessoa>();
			pai.AdicionarFilho(this);
		}
		public void AdicionarFilho(Pessoa filho)
		{
			this.filhos.Add(filho);
		}
		public void Conjuge(Pessoa conjuge)
		{
			this.conjuge = conjuge;
			conjuge.conjuge = this;
		}
		public void ImprimeArvore(int contador)
		{
			Console.Write(new string(' ', contador * 4) + "--> " + this.nome);
		
			if (this.conjuge != null && this.filhos.Count > 0)
			{
				Console.Write(" é casado(a) com " + this.conjuge.nome + ", filhos:");
			}
			else
			{
				if (this.conjuge != null && this.filhos.Count == 0)
				{
					Console.WriteLine(" é casado(a) com " + this.conjuge.nome);
				}
				else
				{
					Console.WriteLine(" é solteiro(a)");
				}
			}
				
			if (this.filhos.Count > 0)
			{
				Console.WriteLine(new string(' ', contador * 4));
				foreach (var filho in this.filhos)
				{
					filho.ImprimeArvore(contador + 1);
				}
			}
			
		}
	}
}
