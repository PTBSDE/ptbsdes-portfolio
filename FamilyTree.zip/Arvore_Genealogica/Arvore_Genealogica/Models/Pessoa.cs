﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arvore_Genealogica.Models
{
	public class Pessoa
	{
		public string nome;
		public Pessoa pai;
		public Pessoa mae;
		public Pessoa conjuge;
		public List<Pessoa> filhos;
		public Pessoa(string nome)
		{
			this.nome = nome;
			this.filhos = new List<Pessoa>();
		}
		public Pessoa(string nome, Pessoa pai)
		{
			this.nome = nome;
			this.pai = pai;
			this.filhos = new List<Pessoa>();
			pai.AdicionarFilho(this);
		}
		public void AdicionarFilho(Pessoa filho)
		{
			this.filhos.Add(filho);
		}
		public void Conjuge(Pessoa conjuge)
		{
			this.conjuge = conjuge;
			conjuge.conjuge = this;
		}
		public void ImprimeArvore(int nivel)
		{
			Console.WriteLine(new string(' ', nivel * 2) + this.nome);
			if (this.conjuge != null)
			{
				Console.WriteLine(new string(' ', nivel * 2) + $"{this.nome} é casado(a) com {this.conjuge.nome}, seus filhos são:");
				foreach (Pessoa filho in this.filhos)
				{
					Console.WriteLine(new string(' ', (nivel + 1) * 2) + $"- {filho.nome}");
					if (filho.conjuge == null)
					{
						Console.WriteLine(new string(' ', (nivel + 1) * 2) + $"{filho.nome} é solteiro(a)");
					}
				}
			}
			foreach (Pessoa filho in this.filhos)
			{
				filho.ImprimeArvore(nivel + 1);
			}
		}
	}
}
