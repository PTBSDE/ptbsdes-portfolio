﻿using Roda_Gigante.Models;
using System;

class Program
{
	static void Main(string[] args)
	{
		// Criando nova roda gigante
		RodaGigante roda = new RodaGigante();
		// Adulto com o nome Paulo
		Adulto paulo = new Adulto("Paulo", 42);
		// Filhos do Paulo
		// Nova criança cujo pai é Paulo										
		Crianca joao = new Crianca("Joao", 5, paulo);
		// Esta é a filha do Paulo
		Crianca maria = new Crianca("Maria", 12, paulo);
		// Crianca sem pai definido												 
		Crianca pedro = new Crianca("Pedro", 13);
		// Crianca sem pai definido
		Crianca henrique = new Crianca("Henrique", 10);
		/*
		* Agora vem a parte divertida. Foi criada uma regra no parque:
		* - Crianças menores de 12 anos só podem andar acompanhadas do pai!
		*
		*/
		roda.embarcar(2, joao, maria); // ERRO: João é menor de 12 e o pai não está junto
		roda.embarcar(2, joao, paulo); // OK: Agora o pai está junto
		roda.embarcar(3, maria); // OK: Maria já tem 12 anos e pode andar sozinha
		roda.embarcar(13, pedro); // OK: O Pedro vai sozinho
		roda.embarcar(16, henrique);//ERRO: henrique é menor de 12 anos e não sabemos quem
									// é o pai (deve ser o Silvio, mas ele não assumiu!)
		roda.status();
		/*
		* Deve imprimir:
		*
		* Gôndola Status
		* ------- -----------------------
		* 1 (vazia)
		* 2 João e Paulo
		* 3 Somente Maria
		* 4 (vazia)
		* 5 (vazia)
		* 6 (vazia)
		* 7 (vazia)
		* 8 (vazia)
		* 9 (vazia)
		* 10 (vazia)
		* 11 (vazia)
		* 12 (vazia)
		* 13 Somente Pedro
		* 14 (vazia)
		* 15 (vazia)
		* 16 (vazia)
		* 17 (vazia)
		* 18 (vazia)
		*/

		Console.ReadLine();
	}
}