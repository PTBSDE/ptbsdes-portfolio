﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roda_Gigante.Models
{
	public class Crianca : Pessoa
	{
		public Adulto Responsavel { get; set; }

		public Crianca(string nome, int idade, Adulto pai = null)
		{
			this.Nome = nome;
			this.Idade = idade;
			this.Responsavel = pai;
		}
	}
}
