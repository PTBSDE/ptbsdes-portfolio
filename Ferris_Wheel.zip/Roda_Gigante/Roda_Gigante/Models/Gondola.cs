﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roda_Gigante.Models
{
	public class Gondola
	{
		public int Numero { get; set; }

		public Pessoa Assento1 { get; set; }

		public Pessoa Assento2 { get; set; }
	}
}