﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roda_Gigante.Models
{
	public class Adulto : Pessoa
	{
		public Adulto(string nome, int idade)
		{
			this.Nome = nome;
			this.Idade = idade;
		}
	}
}
