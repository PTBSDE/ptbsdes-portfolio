﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roda_Gigante.Models
{
	public class RodaGigante
	{
		public List<Gondola> Gondolas { get; set; }

		public RodaGigante()
		{
			Gondolas = new List<Gondola>();
			for (int i = 1; i <= 18; i++)
			{
				Gondolas.Add(new Gondola() { Numero = i });
			}
		}

		public void embarcar(int numero, Crianca pessoa1, Pessoa pessoa2 = null)
		{
			if (pessoa1.Idade < 12)
			{
				if (pessoa2 == pessoa1.Responsavel && pessoa2 != null)
				{
					Gondolas.Where(g => g.Numero == numero).FirstOrDefault().Assento1 = pessoa1;
					Gondolas.Where(g => g.Numero == numero).FirstOrDefault().Assento2 = pessoa2;
					return;
				}
				else
				{
					Console.WriteLine($"{pessoa1.Nome} é menor de 12 e o pai não está junto");
				}
			}

			else
			{
				Gondolas.Where(g => g.Numero == numero).FirstOrDefault().Assento1 = pessoa1;
				return;
			}

		}

		public void embarcar(Crianca pessoa1, Pessoa pessoa2 = null)
		{
			if (pessoa1.Idade < 12)
			{
				if (pessoa2 == pessoa1.Responsavel && pessoa2 != null)
				{

					foreach (var gondola in Gondolas)
					{
						if (gondola.Assento1 == null)
						{
							gondola.Assento1 = pessoa1;
							gondola.Assento2 = pessoa2;
							break;
						}

					}
				}
				else
				{
					Console.WriteLine($"{pessoa1.Nome} é menor de 12 e o pai não está junto");
				}
			}
			else
			{
				foreach (var gondola in Gondolas)
				{
					if (gondola.Assento1 == null)
					{
						gondola.Assento1 = pessoa1;
						break;
					}
				}
			}
		}

		public void status()
		{
			Console.WriteLine("Gôndola Status");
			Console.WriteLine("------- -----------------------");
			foreach (var gondola in Gondolas)
			{
				if (gondola.Assento1 != null)
				{

					if (gondola.Assento2 is null)
					{
						Console.WriteLine($"{gondola.Numero} Somente {gondola.Assento1.Nome}");
					}

					else
					{
						Console.WriteLine($"{gondola.Numero} {gondola.Assento1.Nome} e {gondola.Assento2.Nome}");
					}
				}
				else
				{
					Console.WriteLine($"{gondola.Numero} (vazia)");
				}
			}
		}
	}
}
