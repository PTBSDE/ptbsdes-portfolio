﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Conta_Bancaria
{
	class Program
	{
		private static List<Cliente> clientesList = new List<Cliente>();
		private static List<Conta> contasList = new List<Conta>();

		static void Main(string[] args)
		{
			while (true)
			{
				Console.WriteLine("Menu:");
				Console.WriteLine("1. Cadastrar Cliente");
				Console.WriteLine("2. Cadastrar Conta");
				Console.WriteLine("3. Acessar Conta");
				Console.WriteLine("4. Sair");
				Console.Write("Escolha uma opção: ");
				string opcao = Console.ReadLine();

				switch (opcao)
				{
					case "1":
						CadastrarCliente();
						break;
					case "2":
						CadastrarConta();
						break;
					case "3":
						AcessarConta();
						break;
					case "4":
						return;
					default:
						Console.WriteLine("Opção inválida");
						break;
				}
			}
		}

		private static void CadastrarCliente()
		{
			Console.Write("Informe o nome do cliente: ");
			string nome = Console.ReadLine();
			if (!IsValidNome(nome))
			{
				Console.WriteLine("Nome inválido. Deve conter apenas letras.");
				return;
			}

			Console.Write("Informe o CPF do cliente: ");
			string cpfInput = Console.ReadLine();
			if (!IsValidCpf(cpfInput))
			{
				Console.WriteLine("CPF inválido. Deve conter 11 dígitos numéricos.");
				return;
			}

			long cpf = long.Parse(cpfInput);

			if (clientesList.Any(c => c.Cpf == cpf))
			{
				Console.WriteLine("CPF já cadastrado.");
				return;
			}

			Cliente cliente = new Cliente(nome, cpf);
			clientesList.Add(cliente);
			Console.WriteLine("Cliente cadastrado com sucesso.");
		}

		private static void CadastrarConta()
		{
			Console.Write("Informe o CPF do cliente: ");
			string cpfInput = Console.ReadLine();
			if (!IsValidCpf(cpfInput))
			{
				Console.WriteLine("CPF inválido. Deve conter 11 dígitos numéricos.");
				return;
			}

			long cpf = long.Parse(cpfInput);
			Cliente cliente = clientesList.FirstOrDefault(c => c.Cpf == cpf);

			if (cliente == null)
			{
				Console.WriteLine("Cliente não encontrado. Certifique-se de que o CPF está correto e que o cliente está cadastrado.");
				return;
			}

			Conta conta = new Conta(cliente, 0);
			contasList.Add(conta);
			Console.WriteLine("Conta cadastrada com sucesso. Número da conta: " + conta.ContaId);
		}

		private static void AcessarConta()
		{
			Console.Write("Informe o número da conta: ");
			if (!int.TryParse(Console.ReadLine(), out int contaId))
			{
				Console.WriteLine("Número de conta inválido.");
				return;
			}

			Console.Write("Informe o CPF do cliente: ");
			string cpfInput = Console.ReadLine();
			if (!IsValidCpf(cpfInput))
			{
				Console.WriteLine("CPF inválido. Deve conter 11 dígitos numéricos.");
				return;
			}

			long cpf = long.Parse(cpfInput);
			Conta conta = contasList.FirstOrDefault(c => c.ContaId == contaId && c.Cliente.Cpf == cpf);

			if (conta == null)
			{
				Console.WriteLine("Conta não encontrada. Certifique-se de que o CPF e o número da conta estão corretos.");
				return;
			}

			Console.WriteLine("Acesso concedido!");

			while (true)
			{
				Console.WriteLine("Menu da Conta:");
				Console.WriteLine("1. Sacar");
				Console.WriteLine("2. Depositar");
				Console.WriteLine("3. Transferir");
				Console.WriteLine("4. Consultar Saldo");
				Console.WriteLine("5. Voltar");
				Console.Write("Escolha uma opção: ");
				string opcao = Console.ReadLine();

				switch (opcao)
				{
					case "1":
						Sacar(conta);
						break;
					case "2":
						Depositar(conta);
						break;
					case "3":
						Transferir(conta);
						break;
					case "4":
						ConsultarSaldo(conta);
						break;
					case "5":
						return;
					default:
						Console.WriteLine("Opção inválida");
						break;
				}
			}
		}

		private static void Sacar(Conta conta)
		{
			Console.Write("Informe o valor para saque: ");
			if (double.TryParse(Console.ReadLine(), out double valor) && valor > 0)
			{
				if (conta.Saldo >= valor)
				{
					conta.Saldo -= valor;
					Console.WriteLine("Saque realizado com sucesso. Saldo atual: " + conta.Saldo);
				}
				else
				{
					Console.WriteLine("Saldo insuficiente.");
				}
			}
			else
			{
				Console.WriteLine("Valor inválido.");
			}
		}

		private static void Depositar(Conta conta)
		{
			Console.Write("Informe o valor para depósito: ");
			if (double.TryParse(Console.ReadLine(), out double valor) && valor > 0)
			{
				conta.Saldo += valor;
				Console.WriteLine("Depósito realizado com sucesso. Saldo atual: " + conta.Saldo);
			}
			else
			{
				Console.WriteLine("Valor inválido.");
			}
		}

		private static void Transferir(Conta conta)
		{
			Console.Write("Informe o número da conta de destino: ");
			if (int.TryParse(Console.ReadLine(), out int contaDestinoId))
			{
				Conta contaDestino = contasList.FirstOrDefault(c => c.ContaId == contaDestinoId);
				if (contaDestino == null)
				{
					Console.WriteLine("Conta de destino não encontrada.");
					return;
				}

				Console.Write("Informe o valor para transferência: ");
				if (double.TryParse(Console.ReadLine(), out double valor) && valor > 0)
				{
					if (conta.Saldo >= valor)
					{
						conta.Saldo -= valor;
						contaDestino.Saldo += valor;
						Console.WriteLine("Transferência realizada com sucesso. Saldo atual: " + conta.Saldo);
					}
					else
					{
						Console.WriteLine("Saldo insuficiente.");
					}
				}
				else
				{
					Console.WriteLine("Valor inválido.");
				}
			}
			else
			{
				Console.WriteLine("Número de conta de destino inválido.");
			}
		}

		private static void ConsultarSaldo(Conta conta)
		{
			Console.WriteLine("Saldo atual: " + conta.Saldo);
		}

		public static bool IsValidNome(string nome)
		{
			return nome.All(char.IsLetter);
		}

		public static bool IsValidCpf(string cpf)
		{
			return cpf.Length == 11 && cpf.All(char.IsDigit);
		}
	}
}