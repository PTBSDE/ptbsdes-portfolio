﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conta_Bancaria
{
	internal class Conta
	{
		public static int contaIdCounter = 0001;

		public int ContaId { get; set; }
		public Cliente Cliente { get; set; }
		public double Saldo { get; set; }

		public Conta(Cliente cliente, double saldo)
		{
			this.ContaId = contaIdCounter++;
			this.Cliente = cliente;
			this.Saldo = saldo;
		}
	}
}
