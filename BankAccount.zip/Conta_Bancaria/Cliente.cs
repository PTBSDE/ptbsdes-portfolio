﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conta_Bancaria
{
	internal class Cliente
	{
		public string Nome { get; set; }
		public long Cpf { get; set; }

		public Cliente(string nome, long cpf)
		{
			this.Nome = nome;
			this.Cpf = cpf;
		}	
	}
}

